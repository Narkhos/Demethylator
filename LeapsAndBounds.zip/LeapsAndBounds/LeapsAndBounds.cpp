﻿#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <map>
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <GL/glew.h>
#include "sfxr.hpp"
#include "gui.hpp"
#include "json.hpp"

#ifdef _MSC_VER
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#endif

using namespace std;

SDL_Window* window;
TexturePool texturePool("./data/images/");

SDL_Color webColorToRGB(const char* fillStyle)
{
	SDL_Color rgb = { 255, 255, 255, 255};
	string tmp(fillStyle);
	string r;
	string g;
	string b;

	if (strlen(fillStyle) == 4)
	{
		r = tmp.substr(1, 1) + tmp.substr(1, 1);
		g = tmp.substr(2, 1) + tmp.substr(2, 1);
		b = tmp.substr(3, 1) + tmp.substr(3, 1);
	}
	else
	{
		r = tmp.substr(1, 2);
		g = tmp.substr(3, 2);
		b = tmp.substr(5, 2);
	}

	stringstream r_ss;
	r_ss << std::hex << r;
	r_ss >> rgb.r;

	stringstream g_ss;
	g_ss << std::hex << g;
	g_ss >> rgb.g;

	stringstream b_ss;
	b_ss << std::hex << b;
	b_ss >> rgb.b;

	// cout << fillStyle << " : " << r << g << b << " : " << rgb.r << ", "<< rgb.g << ", "<< rgb.b <<endl;
	return rgb;
}

class DiscreetGauge
{
public:
	vector<GUI_Button> buttonList;
	TTF_Font* font;
	GLuint labelTexId;
	float x;
	float y;
	int value;
	wstring label;
	int label_w;
	int label_h;
	SDL_Color textColor;

	DiscreetGauge(
		int initValue,
		int textureButton,
		int textureButtonZero,
		float _x,
		float _y,
		float buttonWidth,
		float buttonHeight,
		int length,
		TTF_Font* _font,
		wstring _label,
		SDL_Color _textColor)
		:value(initValue), x(_x), y(_y), font(_font), textColor(_textColor), label(_label)
	{
		labelTexId = texteToTexture(font, textColor, _label, this->label_w, this->label_h);

		int idTextureButton = textureButtonZero;
		for (int i = 0; i < length; i++)
		{
			buttonList.push_back(GUI_Button(idTextureButton, _x + (i * buttonWidth), _y + this->label_h, buttonWidth, buttonHeight, 2));
			idTextureButton = textureButton;
		}

		this->updateButtons();
	}

	void updateTextColor(const SDL_Color &newColor)
	{
		if (newColor.r != this->textColor.r
			|| newColor.g != this->textColor.g
			|| newColor.b != this->textColor.b
			|| newColor.a != this->textColor.a)
		{
			this->textColor = newColor;
			glDeleteTextures(1, &labelTexId);
			labelTexId = texteToTexture(font, this->textColor, this->label, this->label_w, this->label_h);
		}
	}

	void updateButtons()
	{
		// Change state of each button in the gauge
		for (int i = 0; i < this->buttonList.size(); i++)
		{
			buttonList[i].setEtat(i <= this->value ? 0 : 1);
		}
	}

	int onClick(int mouse_x, int mouse_y)
	{
		int newIndex = -1;
		for (int i = 0; i < this->buttonList.size(); i++)
		{
			if (this->buttonList[i].isIn(mouse_x, mouse_y))
			{
				newIndex = i;
				break;
			}
		}

		if (newIndex == -1)
		{
			return -1; // The user does not clicked this gauge
		}

		this->value = newIndex;

		this->updateButtons();

		return this->value; // return gauge value (changed or not)
	}

	void draw()
	{
		drawImage(labelTexId, x, y, (float)this->label_w, (float)this->label_h, 1.0f);
		for (int i = 0; i < this->buttonList.size(); i++)
		{
			buttonList[i].draw();
		}
	}

};

class Config
{
public:
	string filepath;
	nlohmann::json data;

	Config(string _filepath)
		:filepath(_filepath)
	{
		ifstream i(this->filepath);

		i >> data;
	}

	void save()
	{
		ofstream o(filepath);
		o << setw(4) << data << endl;
	}

	void trace()
	{
		cout << data << endl;
	}
};

TTF_Font* font = nullptr;

TTF_Font* loadFont(string filepath)
{
	// INITIALISATION de SDL_ttf
	if (!TTF_WasInit() && TTF_Init() == -1)
	{
		cerr << "TTF_Init : " << TTF_GetError() << endl;
		return NULL;
	}

	TTF_Font* font = TTF_OpenFont(filepath.c_str(), 16);

	if (!font)
	{
		cerr << "TTF_OpenFont : " << TTF_GetError() << endl;
		return NULL;
	}

	TTF_SetFontStyle(font, TTF_STYLE_NORMAL);

	return font;
}

int width = 1024;
int height = 768;
int windowedWidth = 1024;
int windowedHeight = 768;
bool fullscreen = false;
bool showFPS = false;

string gameTitle = "Leaps and Bounds";

void updateAndDrawFPS(int currentTime)
{
	static int frame = 0;
	static GLuint texId = 0;
	static int w = 0;
	static int h = 0;

	frame++;

	static int prec_time = 0;

	int deltatime = currentTime - prec_time;

	if (deltatime >= 1000)
	{
		SDL_Color couleur = { 255, 255, 255, 255 };

		if (texId > 0) glDeleteTextures(1, &texId);
		wstringstream ss;
		ss << L"FPS: " << frame;
		texId = texteToTexture(font, couleur, ss.str(), w, h);
		prec_time = currentTime;
		frame = 0;
	}

	// Draw FPS texture
	if (texId > 0)
	{
		drawImage(texId, 4, 0, (float)w, (float)h, 1.0f);
	}

}

// CONTROLLERS MANAGEMENT

map<int, SDL_GameController *> controllers; ///< Liste des controllers branchés

int addController(int id)
{
	if (SDL_IsGameController(id)) {
		SDL_GameController *pad = SDL_GameControllerOpen(id);

		if (pad)
		{
			SDL_Joystick *joy = SDL_GameControllerGetJoystick(pad);
			int instanceID = SDL_JoystickInstanceID(joy);

			controllers[instanceID] = pad;
			cout << "Branchement du controller " << instanceID << endl;
			return instanceID;
		}
	}
	return -1;
}

void removeController(int id)
{
	cout << "Debranchement du controller " << id << endl;
	SDL_GameController *pad = controllers[id];
	SDL_GameControllerClose(pad);
	controllers[id] = NULL;
	controllers.erase(id);
}

void foundControllers()
{
	for (int i = 0; i < SDL_NumJoysticks(); ++i)
	{
		addController(i);
	}
}

void windowResize(int w, int h)
{
	width = w;
	height = h;
	glViewport(0, 0, width, height);
	glLoadIdentity();

	glOrtho(0, width, height, 0, -1, 1);
}

void toggleFullscreen()
{
	if (fullscreen)
	{
		SDL_SetWindowFullscreen(window, 0);
		cout << width << ", " << height << endl;
		windowResize(windowedWidth, windowedHeight);
		fullscreen = false;
	}
	else
	{
		windowedWidth = width;
		windowedHeight = height;
		SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN_DESKTOP);
		fullscreen = true;
	}
}


// GAME

class Mushroom {
public:
	int bonus;
	GLuint texId;
	float x;
	float y;
	float w;
	float h;

	Mushroom(float _x, float _y, float _w, float _h, bool _bonus)
		:x(_x), y(_y), w(_w), h(_h), bonus(_bonus ? 1 : -1)
	{
		this->texId = texturePool.getTexture(_bonus ? "redmushroom.png" : "greenmushroom.png")->texId;
	}

	~Mushroom()
	{
	}

	void draw()
	{
		drawImage(this->texId, this->x, this->y, this->w, this->h, 1.0f);
	}
};

class Player {
public:
	int level;
	GLuint texId[5];
	float x;
	float y;
	float w;
	float h;
	float xSpeed;
	float ySpeed;

	Player(float _x, float _y, float _w, float _h, bool _level)
		:x(_x), y(_y), w(_w), h(_h), level(_level), xSpeed(0), ySpeed(0)
	{
		for (int i = 0; i < 5; i++) {
			stringstream ss;
			ss << "player" << i + 1 << ".png";
			cout << ss.str() << endl;
			this->texId[i] = texturePool.getTexture(ss.str())->texId;
		}
	}

	~Player()
	{
	}

	void evolve()
	{
		this->level = min(this->level + 1, 4);
		cout << this->texId[this->level] << endl;
	}

	void degenerate()
	{
		this->level = max(this->level - 1, 0);
		cout << this->texId[this->level] << endl;
	}

	void update(int deltaTime)
	{
		this->x += deltaTime * xSpeed * 0.2;
		this->y += deltaTime * ySpeed * 0.2;
	}
	void draw()
	{
		drawImage(this->texId[this->level], this->x, this->y, this->w, this->h, 1.0f);
	}
};

// MAIN
int main(int argc, char* argv[])
{
	Config config("./config.json");
	width = config.data["width"];
	height = config.data["height"];
	fullscreen = config.data["fullscreen"];

	windowedWidth = width;
	windowedHeight = height;

	SDL_GLContext glContext;
	SDL_Event event;

	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 4);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
	/* This makes our buffer swap syncronized with the monitor's vertical refresh */
	SDL_GL_SetSwapInterval(1);

	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER | SDL_INIT_AUDIO) < 0)
	{
		string msg = "SDL failed to initialize: ";
		msg.append(SDL_GetError());
		SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Init Failed", msg.c_str(), nullptr);
		return 0;
	}

	if (Mix_OpenAudio(44100, AUDIO_S16SYS, 2, 1024) < 0)
	{
		printf("Error initializing SDL_mixer: %s\n", Mix_GetError());
		exit(1);
	}

	int nbMappingsAdded = SDL_GameControllerAddMappingsFromFile("./data/gamecontrollerdb.txt");
	if (nbMappingsAdded == -1)
	{
		cout << SDL_GetError() << endl;
	}
	else
	{
		cout << "Nombre de mappings ajoutes : " << nbMappingsAdded << endl;
	}

	foundControllers();

	Uint32 flags = SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE;
	if (fullscreen) flags = flags | SDL_WINDOW_FULLSCREEN_DESKTOP;
	window = SDL_CreateWindow(gameTitle.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, flags);

	if (window == nullptr)
	{
		std::string msg = "Window could not be created: ";
		msg.append(SDL_GetError());
		SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Init Failed", msg.c_str(), nullptr);
		return 0;
	}

	glContext = SDL_GL_CreateContext(window);

	if (glContext == nullptr)
	{
		std::string msg = "OpenGL context could not be created: ";
		msg.append(SDL_GetError());
		SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Init Failed", msg.c_str(), nullptr);
		return 0;
	}

	// initSfxr();

	font = loadFont("./data/fonts/OxygenMono-Regular.ttf");

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glClearColor(0.5f, 0.5f, 0.5f, 1.0);
	glViewport(0, 0, width, height);
	glOrtho(0, width, height, 0, -1, 1);

	// Disable vsync for performance purpose
	SDL_GL_SetSwapInterval(0);

	glewInit();

	Mushroom redMushroom(100, 100, 64, 64, true);
	Mushroom greenMushroom(150, 100, 64, 64, false);
	Player player1(300, 300, 128, 128, 2);

	// INIT MAIN LOOP
	bool running = true;
	int currentTime = SDL_GetTicks();
	int precTime = currentTime;
	int deltaTime = 0;

	int mouse_x = 0;
	int mouse_y = 0;

	// MAIN LOOP
	while (running)
	{
		// TIME
		currentTime = SDL_GetTicks();
		deltaTime = currentTime - precTime;
		precTime = currentTime;

		// UPDATES
		player1.update(deltaTime);
		// MOUSE
		SDL_GetMouseState(&mouse_x, &mouse_y);

		// INPUTS
		SDL_Keymod keyMod = SDL_GetModState();

		const Uint8* keyState = SDL_GetKeyboardState(nullptr);

		player1.xSpeed = 0;
		player1.ySpeed = 0;
		if (keyState[SDL_SCANCODE_UP] ) {
			player1.ySpeed = -1;
		}

		if (keyState[SDL_SCANCODE_DOWN]) {
			player1.ySpeed = 1;
		}

		if (keyState[SDL_SCANCODE_LEFT]) {
			player1.xSpeed = -1;
		}

		if (keyState[SDL_SCANCODE_RIGHT]) {
			player1.xSpeed = 1;
		}

		while (SDL_PollEvent(&event) != 0)
		{
			switch (event.type)
			{
			case SDL_CONTROLLERDEVICEADDED:
				addController(event.cdevice.which);
				break;
			case SDL_CONTROLLERDEVICEREMOVED:
				removeController(event.cdevice.which);
				break;
			case SDL_CONTROLLERBUTTONDOWN:
				switch (event.cbutton.button)
				{
				case SDL_CONTROLLER_BUTTON_START:
					
					break;
				case SDL_CONTROLLER_BUTTON_A:
					
					break;
				case SDL_CONTROLLER_BUTTON_B:
					
					break;
				case SDL_CONTROLLER_BUTTON_BACK:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_LEFT:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_UP:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_DOWN:
					
					break;
				default:
					cout << (int)(event.cbutton.button) << endl;
				}
				break;
			case SDL_CONTROLLERBUTTONUP:
				switch (event.cbutton.button)
				{
				case SDL_CONTROLLER_BUTTON_START:
					
					break;
				case SDL_CONTROLLER_BUTTON_A:
					
					break;
				case SDL_CONTROLLER_BUTTON_B:
					
					break;
				case SDL_CONTROLLER_BUTTON_BACK:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_LEFT:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_UP:
					
					break;
				case SDL_CONTROLLER_BUTTON_DPAD_DOWN:
					
					break;
				default:
					cout << (int)(event.cbutton.button) << endl;
				}
				break;
			case SDL_MOUSEMOTION:
				
				break;
			case SDL_MOUSEBUTTONDOWN:
				
				break;
			case SDL_MOUSEBUTTONUP:

				break;
			case SDL_WINDOWEVENT:
				if (event.window.event == SDL_WINDOWEVENT_RESIZED)
				{
					windowResize(event.window.data1, event.window.data2);
				}
				break;
			case SDL_QUIT:
				running = false;
				break;
			case SDL_KEYDOWN:
				if (event.key.keysym.sym == SDLK_RETURN)
				{
					if (keyMod & KMOD_ALT)
					{
						toggleFullscreen();
					}
				}

				if (event.key.keysym.sym == SDLK_TAB)
				{
					showFPS = !showFPS;
				}

				break;
			case SDL_KEYUP:
				if (event.key.keysym.sym == SDLK_o) {
					player1.evolve();
				}

				if (event.key.keysym.sym == SDLK_p) {
					player1.degenerate();
				}
				break;
			}
		}

		// DISPLAY
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// display framerate
		if (showFPS) updateAndDrawFPS(currentTime);

		redMushroom.draw();
		greenMushroom.draw();
		player1.draw();

		SDL_GL_SwapWindow(window);
	}
	
	SDL_GL_DeleteContext(glContext);
	glContext = nullptr;
	SDL_DestroyWindow(window);
	window = nullptr;
	Mix_CloseAudio();
	SDL_Quit();

	return 0;
}
